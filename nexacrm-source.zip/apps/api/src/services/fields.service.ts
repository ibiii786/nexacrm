import prisma from '../config/database';

export class FieldsService {
  static async getFields(includeArchived: boolean = false) {
    return prisma.field.findMany({
      where: includeArchived ? undefined : { isArchived: false },
      orderBy: { position: 'asc' }
    });
  }

  static async getFieldById(id: string) {
    return prisma.field.findUnique({
      where: { id }
    });
  }

  static async createField(data: {
    name: string;
    label: string;
    type: string;
    isRequired?: boolean;
    isVisible?: boolean;
    isGlobal?: boolean;
    options?: any;
    position: number;
    isCopyable?: boolean;
    copyPosition?: number | null;
    addedBy: string;
  }) {
    return prisma.field.create({
      data: {
        name: data.name,
        label: data.label,
        type: data.type,
        isRequired: data.isRequired,
        isVisible: data.isVisible,
        isGlobal: data.isGlobal,
        options: data.options,
        position: data.position,
        isCopyable: data.isCopyable,
        copyPosition: data.copyPosition,
        addedBy: data.addedBy,
      }
    });
  }

  static async updateField(id: string, data: {
    name?: string;
    label?: string;
    type?: string;
    isRequired?: boolean;
    isVisible?: boolean;
    isGlobal?: boolean;
    isArchived?: boolean;
    options?: any;
    position?: number;
    isCopyable?: boolean;
    copyPosition?: number | null;
  }) {
    return prisma.field.update({
      where: { id },
      data
    });
  }

  static async deleteField(id: string) {
    // Soft delete by marking as archived
    return prisma.field.update({
      where: { id },
      data: { isArchived: true }
    });
  }
}
